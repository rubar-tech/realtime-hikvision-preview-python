	    
	    var webhelpSearchRanking = true;
	    
	      
	          var webhelpEnableSearchAutocomplete = true;
	        